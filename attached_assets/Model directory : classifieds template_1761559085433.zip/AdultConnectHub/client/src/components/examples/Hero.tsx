import Hero from "../Hero";

export default function HeroExample() {
  return (
    <div className="bg-background">
      <Hero />
    </div>
  );
}
